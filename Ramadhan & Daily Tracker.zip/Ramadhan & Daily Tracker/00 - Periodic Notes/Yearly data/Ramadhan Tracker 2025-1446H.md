---
has_exercise: true
kajian: true
journaling: true
tilawah: 2
r_sahur: "1"
dzikir_pagi: true
dzikir_petang: true
s_dhuha: "1"
s_rawatib: "1"
s_tarawih: "1"
s_tahajud: "1"
proudness: 11
start_ramadhan_2025: 2025-02-22T00:00:00+07:00
end_ramadhan_2025: 2025-02-31
---
 
 `BUTTON[daily-note,light-mode, dark-mode]` 
 - Tanggal 01 Ramadhan 1446 dalam masehi : `INPUT[datePicker:start_ramadhan_2025]` 
  - Tanggal 30 Ramadhan 1446 dalam masehi : `INPUT[datePicker:end_ramadhan_2025]`

```dataviewjs
const meta = dv.current();
const startDate = meta.start_ramadhan_2025 //? moment(meta.start_ramadhan_2025) : moment('2025-01-13');
const endDate   = meta.end_ramadhan_2025 //? moment(meta.start_ramadhan_2025) : moment('2025-01-13');
 const pages = dv.pages('"00 - Periodic Notes/Daily data"')
  .where(p =>  (p.file.day >= startDate) && (p.file.day <= endDate))
   .sort((p) => p.file.day, "desc")
   .map((p) =>
     Object.create({
       link: p.file.link,
       day: p.file.day,
			 r_sahur:p.r_sahur,
			 dzikir_pagi:p.dzikir_pagi,
			 dzikir_petang:p.dzikir_petang,
			 s_wajib:p.s_wajib,
			 s_dhuha:p.s_dhuha,
			 s_rawatib:p.s_rawatib,
			 s_tarawih:p.s_tarawih,
			 s_tahajud:p.s_tahajud,
			 kajian:p.kajian,
			 sedekah:p.sedekah,
			 tilawah:p.tilawah,
			 puasa:p.puasa
     })
   );
 function getStreak(validate) {
   let count = 0;
   for (const note of pages) {
     if (validate(note)) count++;
     else break;
   }
   return count;
 }
 function getRecord(validate) {
  let total = 0;
  
  for (const note of pages) {
    if (validate(note)) {
      total++;
    }
  }

  return total;
}

 
const lv0 = "◻️"
const lv1 = "🟨"
const lv2 = "🟦"
const lv3 = "✅"

const getLevel = (val) => (!val ? lv0 : val === 1 ? lv1 : val === 2 ? lv2 : lv3);
const getScore = (val) => 
  val == null ? 0 : // Kalau null atau undefined, kasih 0
  typeof val === "boolean" ? (val ? 3 : 0) : // Kalau boolean, true = 3, false = 0
  [0, 1, 2, 3].includes(val) ? val : 0; // Kalau angka valid, pakai angkanya, selain itu kasih 0


const totalScore = (note) => 
  getScore(note.r_sahur) +
  getScore(note.dzikir_pagi) +
  getScore(note.dzikir_petang) +
  getScore(note.s_wajib) +
  getScore(note.s_rawatib) +
  getScore(note.s_dhuha) +
  getScore(note.s_tarawih) +
  getScore(note.s_tahajud) +
  getScore(note.kajian) +
  getScore(note.sedekah) +
  getScore(note.tilawah) +
  getScore(note.puasa);

 
const fileRows = pages 
.sort((p) => p.day) 
.map((note) => [  
note.link,
//moment.duration(note.day.diff(startDate)).asDays()+1,
getLevel(note.r_sahur), getLevel(note.dzikir_pagi), getLevel(note.dzikir_petang), getLevel(note.s_wajib), getLevel(note.s_rawatib), getLevel(note.s_dhuha), getLevel(note.s_tarawih), getLevel(note.s_tahajud), getLevel(note.kajian), getLevel(note.sedekah), getLevel(note.tilawah), getLevel(note.puasa),  Math.round(100*totalScore(note)/36) // Menampilkan score harian 
]);
 
 const d_r_sahur = [
   getStreak((note) => note.r_sahur),
   getRecord((note) => note.r_sahur),
 ]; 
 
 const d_dzikir_pagi = [
   getStreak((note) => note.dzikir_pagi),
   getRecord((note) => note.dzikir_pagi),
 ];
 const d_dzikir_petang = [
   getStreak((note) => note.dzikir_petang),
   getRecord((note) => note.dzikir_petang),
 ];  
 
 const d_s_wajib = [
   getStreak((note) => note.s_wajib),
   getRecord((note) => note.s_wajib),
 ];  
 const d_s_dhuha = [
   getStreak((note) => note.s_dhuha),
   getRecord((note) => note.s_dhuha),
 ];
 const d_s_rawatib = [
   getStreak((note) => note.s_rawatib),
   getRecord((note) => note.s_rawatib),
 ];  
 
 const d_s_tarawih = [
   getStreak((note) => note.s_tarawih),
   getRecord((note) => note.s_tarawih),
 ];
 const d_s_tahajud = [
   getStreak((note) => note.s_tahajud),
   getRecord((note) => note.s_tahajud),
 ];  
 
 const d_kajian = [
   getStreak((note) => note.kajian),
   getRecord((note) => note.kajian),
 ];
 const d_sedekah = [
   getStreak((note) => note.sedekah),
   getRecord((note) => note.sedekah),
 ];  
 const d_tilawah = [
   getStreak((note) => note.tilawah),
   getRecord((note) => note.tilawah),
 ];  
 const d_puasa = [
   getStreak((note) => note.puasa),
   getRecord((note) => note.puasa),
 ];  


 dv.table(
   ["Hari","🥣","🌅", "🌇", "🙏","🏰","🌞","🌆","🌙","🔬","💙","📖","🌙","Score"
   ],
   [
     ...fileRows, 
        ["*Streak🔥*"  ,d_r_sahur[0],d_dzikir_pagi[0], d_dzikir_petang[0],d_s_wajib[0],d_s_rawatib[0],d_s_dhuha[0],d_s_tarawih[0],d_s_tahajud[0],
   d_kajian[0], d_sedekah[0],d_tilawah[0],d_puasa[0] 
     ],
     ["*Total*",d_r_sahur[1],d_dzikir_pagi[1], d_dzikir_petang[1],d_s_wajib[1],d_s_rawatib[1],d_s_dhuha[1],d_s_tarawih[1],d_s_tahajud[1] ,
	 d_kajian[1], d_sedekah[1],d_tilawah[1],d_puasa[1] 
     ],
   ]
 );

```
<span style="font-size: 9px; display: inline-block;">
**Keterangan**: ✅ Mantap!, 🟦 Dikit lagi!, 🟨 Setengah jalan!, ◻️ Belum nih!.  
**Score**: akumulasi amalan harian dengan tiap amalan diboboti 3 poin jika ✅ (lalu di-*rescale* ke rentang 0-100).
</span>

 >[!tip] Progress Tilawah Ramadhan
>  ```dataviewjs
const meta = dv.current();
const startDate = meta.start_ramadhan_2025;
const endDate = meta.end_ramadhan_2025;
>
const pages = dv.pages('"00 - Periodic Notes/Daily data"').where(p => (p.file.day >= startDate) && (p.file.day <= endDate));
>
const tilawahData = pages.filter(p => p.tilawah_last_juz).map(p => ({juz: p.tilawah_last_juz,surah: p.tilawah_last_surah,ayat: p.tilawah_last_ayat}));
>
// Ambil nilai terakhir yang ada
const lastTilawah = tilawahData.length > 0 ? tilawahData[tilawahData.length - 1] : { juz: 0, surah: "Belum ada", ayat: "-" };
const maxJuz = Math.max(...tilawahData.map(p => p.juz), 0);
>
const progress = lastTilawah.juz || 0;
const target = 30;
const percentage = Math.round((progress / target) * 100);
>
// Menyesuaikan warna teks agar selalu terbaca 
const textInside = percentage >= 50; 
const textColor = textInside ? "white" : "black"; 
const textPosition = textInside ? "center" : "right: 10px; top: 5px;";
>
// Membuat progress bar dengan teks yang selalu terlihat 
const progressBar = ` <div style="width: 100%; background: #ddd; border-radius: 10px; position: relative; overflow: hidden; height: 30px; display: flex; align-items: center;"> <div style="width: ${percentage}%; background: #4caf50; color: ${textInside ? 'white' : 'transparent'}; padding: 5px; border-radius: 10px; text-align: center; font-weight: bold; height: 100%; display: flex; align-items: center; justify-content: center;"> ${textInside ? `Surat ${lastTilawah.surah}:${lastTilawah.ayat} 📖 Juz ${progress}/30 (${percentage}%)` : ""} </div> ${!textInside ? `<div style="position: absolute; ${textPosition} font-weight: bold; color: black;">Surat ${lastTilawah.surah}:${lastTilawah.ayat} 📖 Juz ${progress}/30 (${percentage}%)</div>` : ""} </div> `; // Render ke dalam notes 
dv.el("div", progressBar);
>```



- ###  #mcl/list-card Ramadhan Performance  - 2025, 1446 H
	```dataviewjs  
	const meta = dv.current();
	const startDate = meta.start_ramadhan_2025;
	const endDate = meta.end_ramadhan_2025;
	dv.span("");  
	const calendarData = {  
	    colors: {    // (optional) defaults to green  
	        green:       ["#ffffff", "#7bc96f", "#49af5d", "#2e8840", "#196127"],
	        blue:        ["#8cb9ff", "#69a3ff", "#428bff", "#1872ff", "#0058e2"],
	        red:         ["#ff9e82", "#ff7b55", "#ff4d1a", "#e73400", "#bd2a00"],
	        orange:      ["#ffa244", "#fd7f00", "#dd6f00", "#bf6000", "#9b4e00"],
	        pink:        ["#ff96cb", "#ff70b8", "#ff3a9d", "#ee0077", "#c30062"],
	        orangeToRed: ["#ffdf04", "#ffbe04", "#ff9a03", "#ff6d02", "#ff2c01"]
	    },  
	    showCurrentDayBorder: true,
	    intensityScaleStart: 1,
	    intensityScaleEnd: 36,
	    entries: [],
	};  
	const getScore = (val) => val == null ? 0 : typeof val === "boolean" ? (val ? 3 : 0) : [0, 1, 2, 3].includes(val) ? val : 0;
	for (let page of dv.pages('"00 - Periodic Notes/Daily data"').where(p => (p.file.day >= startDate) && (p.file.day <= endDate)).sort(p => p.file.day, "desc")) {  
	    let totalScore = 
	        getScore(page.r_sahur) + getScore(page.dzikir_pagi) + getScore(page.dzikir_petang) + 
	        getScore(page.s_wajib) + getScore(page.s_rawatib) + getScore(page.s_dhuha) + 
	        getScore(page.s_tarawih) + getScore(page.s_tahajud) + getScore(page.kajian) + 
	        getScore(page.sedekah) + getScore(page.tilawah) + getScore(page.puasa);
	    
	    calendarData.entries.push({  
	        date: page.file.name,  
	        intensity: totalScore,  
	        content: await dv.span(`[](${page.file.name})`), // for hover preview  
	    });  
	}  
	renderHeatmapCalendar(this.container, calendarData);
	```

 
### Grafik Score Amalan Harian 
```dataviewjs
const meta = dv.current();
const startDate = meta.start_ramadhan_2025;
const endDate = meta.end_ramadhan_2025;

const getScore = (val) => val == null ? 0 : typeof val === "boolean" ? (val ? 3 : 0) : [0, 1, 2, 3].includes(val) ? val : 0;

const pages = dv.pages('"00 - Periodic Notes/Daily data"')
  .where(p => p.file.day >= startDate && p.file.day <= endDate)
  .sort(p => p.file.day, "asc");

const labels = pages.map(p => moment(p.file.name, "YYYY-MM-DD").format("DD MMM")).values;

const scores = pages.map(p => {
  const rawScore = 
    getScore(p.r_sahur) + getScore(p.dzikir_pagi) + getScore(p.dzikir_petang) +
    getScore(p.s_wajib) + getScore(p.s_rawatib) + getScore(p.s_dhuha) +
    getScore(p.s_tarawih) + getScore(p.s_tahajud) + getScore(p.kajian) +
    getScore(p.sedekah) + getScore(p.tilawah) + getScore(p.puasa);

  return Math.round((rawScore / 36) * 100);  // Normalisasi ke 100
}).values;

// Atur tinggi grafik
this.container.style.height = "300px";

const chartData = {
    type: 'line',
    data: {
        labels: labels,
        datasets: [{
            label: 'Performance Score',
            data: scores,
            backgroundColor: 'rgba(76, 175, 80, 0.2)',
            borderColor: '#4caf50',
            borderWidth: 2,
            tension: 0.3,
            fill: true,
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            x: {
                title: {
                    display: true,
                    text: 'Tanggal'
                }
            },
            y: {
                beginAtZero: true,
                suggestedMax: 100, // Skala maksimal 100
                title: {
                    display: true,
                    text: 'Score (%)'
                }
            }
        }
    }
}
window.renderChart(chartData, this.container);
```


### Keterangan Data Amalan Ramadhan

| No  | Amalan                | Variable      | Emoji | Type    |
| --- | --------------------- | ------------- | ----- | ------- |
| 1   | Sahur                 | r_sahur       | 🥣    | biner   |
| 2   | Dzikir Pagi           | dzikir_pagi   | 🌅    | biner   |
| 3   | Dzikir Petang         | dzikir_petang | 🌇    | biner   |
| 4   | Shalat Wajib          | s_dhuha       | 🙏    | biner   |
| 5   | Shalat Sunnah Rawatib | s_rawatib     | 🏰    | biner   |
| 6   | Shalat Sunnah Dhuha   | s_dhuha       | 🌞    | biner   |
| 7   | Shalat Sunnah Tarawih | s_tarawih     | 🌃    | biner   |
| 8   | Shalat Sunnah Tahajud | s_tahajud     | 🌙    | biner   |
| 9   | Kajian                | kajian        | 🔬    | biner   |
| 10  | Sedekah               | sedekah       | 💙    | biner   |
| 11  | Tilawah               | tilawah       | 📖    | ordinal |
| 12  | Puasa                 | puasa         | ✨     | biner   |
|     |                       |               |       |         |

> [!tips]+ Remember
> Segala nikmat yang ada padamu (datangnya) dari ***Allah ﷻ*** . Kemudian, apabila kamu ditimpa kemudaratan, kepada-Nyalah kamu meminta pertolongan. *(An-Nahl · Ayat 53)*
---



  ```meta-bind-button 
  style: primary 
  label: Dark Mode 
  id: dark-mode 
  hidden: true 
  actions: 
  - type: command 
    command: theme:use-dark 
``` 
```meta-bind-button 
style: destructive 
label: Light Mode 
id: light-mode 
hidden: true 
actions: 
- type: command 
  command: theme:use-light 
``` 
```meta-bind-button
style: destructive
label: Homepage
hidden: true
id: homepage
action:
  type: command
  command: homepage:open-homepage
```
```meta-bind-button
style: primary
label: Daily Note
hidden: true
id: daily-note
action:
  type: command
  command: daily-notes
```