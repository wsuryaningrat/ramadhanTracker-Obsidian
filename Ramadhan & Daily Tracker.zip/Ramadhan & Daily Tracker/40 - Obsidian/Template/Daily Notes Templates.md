---
tags: 
banner: 
banner_x: 0.23147
banner_y: 0.61249
date: <% tp.date.now("YYYY-MM-DD") %>
proudness: 1
---
<% await tp.file.move("00 - Periodic Notes/Daily data/"+ tp.date.now("YYYY-MM-DD"))%>  
# <%tp.date.now("dddd, DD MMMM YYYY")%>

`BUTTON[prev-note]` 🪴  `BUTTON[homepage]` 🪴 `BUTTON[next-note]`🪴 `BUTTON[tasks]`
 
> [!check] How was your day ?😊
> ```meta-bind
> INPUT[progressBar(minValue(0),maxValue(10)):proudness]
> ```

# Amalan Tracker

  >[!multi-column] + Judul
  >
 >> [!check]+ Amalan Harian
>> | | |
 >>|---------|---------|
 >> |Sahur      |: `INPUT[toggle(title(r_sahur)):r_sahur]` |
 >> |Puasa      |: `INPUT[toggle(title(r_sahur)):puasa]` |
 >> |Dzikir Pagi      |: `INPUT[toggle(title(r_sahur)):dzikir_pagi]` |
 >> |Dzikir Petang      |: `INPUT[toggle(title(r_sahur)):dzikir_petang]` |
 >> |Sedekah       |: `INPUT[toggle(title(r_sahur)):sedekah]` |
 >
 >> [!check]+ Amalan Shalat 
>> | | |
 >>|---------|---------|
 >> | Wajib      | :  `INPUT[inlineSelect(option(0,null),option(1,partial),option(2,half),option(3,full)):s_wajib]` |
 >> | Rawatib      | :  `INPUT[inlineSelect(option(0,null),option(1,partial),option(2,half),option(3,full)):s_rawatib]` |
 >> |Dhuha      |: `INPUT[toggle(title(r_sahur)):s_dhuha]` |
 >> |Tarawih      |: `INPUT[toggle(title(r_sahur)):s_tarawih]` |
 >> |Tahajud      |: `INPUT[toggle(title(r_sahur)):s_tahajud]` |
 >
 >> [!check]+ Kajian & Tilawah
>> | | |
 >>|---|---| 
 >> | Kajian         | : `INPUT[toggle(title(kajian)):kajian]`   |
 >> | Tilawah      | :  `INPUT[inlineSelect(option(0,null),option(1,<=2 hal.),option(2,2-10 hal.),option(3,>= 10 hal.)):tilawah]` |
 >> | Juz      | :  `INPUT[ number:tilawah_last_juz]` |
 >> | Surat      | :  `INPUT[inlineSelect(option(1,1. Al-Fatihah),option(2,2. Al-Baqarah),option(3,3. Ali Imran),option(4,4. An Nisa),option(5,5. Al Maidah),option(6,6. Al Anam),option(7,7. Al Araf),option(8,8. Al Anfal),option(9,9. At Tawbah),option(10,10. Yunus),option(11,11. Hud),option(12,12. Yusuf),option(13,13. Ar Rad),option(14,14. Ibrahim),option(15,15. Al Hijr),option(16,16. An Nahl),option(17,17. Al Isra),option(18,18. Al Kahf),option(19,19. Maryam),option(20,20. Ta Ha),option(21,21. Al Anbiya),option(22,22. Al Hajj),option(23,23. Al Muminun),option(24,24. An Nur),option(25,25. Al Furqan),option(26,26. Asy Syura),option(27,27. An Naml),option(28,28. Al Qasas),option(29,29. Al Ankabut),option(30,30. Ar Rum),option(31,31. Luqman),option(32,32. As Sajdah),option(33,33. Al Ahzab),option(34,34. Saba),option(35,35. Fatir),option(36,36. Ya Sin),option(37,37. As Saffat),option(38,38. Sad),option(39,39. Az Zumar),option(40,40. Ghafir),option(41,41. Fussilat),option(42,42. Asy Syura),option(43,43. Az Zukhruf),option(44,44. Ad Dukhan),option(45,45. Al Jasiyah),option(46,46. Al Ahqaf),option(47,47. Muhammad),option(48,48. Al Fath),option(49,49. Al Hujurat),option(50,50. Qaf),option(51,51. Az Zariyat),option(52,52. At Tur),option(53,53. An Najm),option(54,54. Al Qamar),option(55,55. Ar Rahman),option(56,56. Al Waqiah),option(57,57. Al Hadid),option(58,58. Al Mujadilah),option(59,59. Al Hasyr),option(60,60. Al Mumtahanah),option(61,61. As Saff),option(62,62. Al Jumuah),option(63,63. Al Munafiqun),option(64,64. At Taghabun),option(65,65. At Talaq),option(66,66. At Tahrim),option(67,67. Al Mulk),option(68,68. Al Qalam),option(69,69. Al Haqqah),option(70,70. Al Maarij),option(71,71. Nuh),option(72,72. Al Jinn),option(73,73. Al Muzzammil),option(74,74. Al Muddassir),option(75,75. Al Qiyamah),option(76,76. Al Insan),option(77,77. Al Mursalat),option(78,78. An Naba),option(79,79. An Naziat),option(80,80. Abasa),option(81,81. At Takwir),option(82,82. Al Infitar),option(83,83. Al Mutaffifin),option(84,84. Al Insyiqaq),option(85,85. Al Buruj),option(86,86. At Tariq),option(87,87. Al Ala),option(88,88. Al Gasyiyah),option(89,89. Al Fajr),option(90,90. Al Balad),option(91,91. Asy Syams),option(92,92. Al Lail),option(93,93. Ad Duha),option(94,94. Asy Syarh),option(95,95. At Tin),option(96,96. Al Alaq),option(97,97. Al Qadr),option(98,98. Al Bayyinah),option(99,99. Az Zalzalah),option(100,100. Al Adiyat),option(101,101. Al Qariah),option(102,102. At Takathur),option(103,103. Al Asr),option(104,104. Al Humazah),option(105,105. Al Fil),option(106,106. Quraisy),option(107,107. Al Maun),option(108,108. Al Kawthar),option(109,109. Al Kafirun),option(110,110. An Nasr),option(111,111. Al Lahab),option(112,112. Al Ikhlas),option(113,113. Al Falaq),option(114,114. An Nas)):tilawah_last_surah]` | 
 >> | Ayat      | :  `INPUT[ number:tilawah_last_ayat]` |
 >> 
 >

## Notes
1. 
## Journaling 
1. 


# Habits Tracker

 ##
  >[!multi-column] + Judul
 >> [!check]+ Literacy + Physic
>> | | |
 >>|---------|---------|
 >> |Journaling      |: `INPUT[toggle(title(journaling)):journaling]` |
 >> |Read  |: `INPUT[inlineSelect(option(0,null),option(1,easy),option(2,medium),option(3,hard)):read]`| 
 >> |Exercise      |: `INPUT[toggle(title(has_exercise)):has_exercise]` |  
 >> | Type      | :  `INPUT[inlineSelect(option(0,null),option(1,Jogging),option(2,Push-Day),option(3,Pull-Day),option(4,Leg-Day)):exercise_type]` |
---




---
`BUTTON[prev-note]` 🪴  `BUTTON[homepage]` 🪴 `BUTTON[next-note]`


```meta-bind-button
style: primary
label: Homepage
hidden: true
id: homepage
action:
  type: command
  command: homepage:open-homepage
```
```meta-bind-button
style: primary
label: Prev
hidden: true
id: prev-note
action:
  type: command
  command: daily-notes:goto-prev
```
```meta-bind-button
style: primary
label: Next
hidden: true
id: next-note
action:
  type: command
  command: daily-notes:goto-next
```
```meta-bind-button
style: destructive
label: View Tasks
hidden: true
id: tasks
action:
  type: command
  command: card-board:open-card-board-plugin-0
```