| No  | Amalan        |     | Emoji |     |
| --- | ------------- | --- | ----- | --- |
| 1   | Sahur         |     | 🥣    |     |
| 2   | Dzikir Pagi   |     | 🌅    |     |
| 3   | Dzikir Petang |     | 🌇    |     |
| 4   | Shalat Wajib  |     | 🙏    |     |
| 5   | Rawatib       |     | 🏰    |     |
| 6   | Dhuha         |     | 🌞    |     |
| 7   | Tarawih       |     | 🌃    |     |
| 8   | Tahajud       |     | 🌙    |     |
| 9   | Kajian        |     | 🔬    |     |
| 10  | Sedekah       |     | 💙    |     |
| 11  | Tilawah       |     | 📖    |     |
| 12  | Puasa         |     | 🌙    |     |
|     |               |     |       |     |
