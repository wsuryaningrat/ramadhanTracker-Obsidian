[[Ramadhan Tracker 2025-1446H]]

> [!tips]+ Remember
> Segala nikmat yang ada padamu (datangnya) dari ***Allah ﷻ*** . Kemudian, apabila kamu ditimpa kemudaratan, kepada-Nyalah kamu meminta pertolongan. *(An-Nahl · Ayat 53)*
